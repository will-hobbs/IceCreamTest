# IceCream

A sample app to illustrate whether refactoring table view data source is good or bad.
